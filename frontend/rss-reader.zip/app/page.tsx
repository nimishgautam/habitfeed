import RSSReader from "../rss-reader"

export default function Page() {
  return <RSSReader />
}
